# filepath: backend/main.py
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import json
import base64
import uvicorn

app = FastAPI()

def decode_athena_eeg(base64_data):
    """
    Athena 12-bit 多路复用解包逻辑
    参考 amused-py 协议实现
    """
    try:
        raw_bytes = base64.b64decode(base64_data)
        if len(raw_bytes) < 5: 
            return []

        samples = []
        # 跳过前 2 字节的包序号
        # 每 3 字节包含 2 个 12-bit 采样点
        for i in range(2, len(raw_bytes) - 2, 3):
            if i + 2 >= len(raw_bytes): 
                break
            b1, b2, b3 = raw_bytes[i], raw_bytes[i+1], raw_bytes[i+2]
            
            # 还原 12-bit 整数
            val1 = (b1 << 4) | (b2 >> 4)
            val2 = ((b2 & 0x0F) << 8) | b3
            
            # 转换为微伏 (减去 2048 偏移量 * 0.475 增益)
            samples.append(round((val1 - 2048) * 0.475, 2))
            samples.append(round((val2 - 2048) * 0.475, 2))
        
        return samples
    except Exception as e:
        print(f"❌ 解析异常: {e}")
        return []

@app.websocket("/ws/eeg")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    print("🟢 数据链路激活，正在解析 Athena 原始流...")
    try:
        while True:
            data = await websocket.receive_text()
            packet = json.loads(data)
            
            # 重点关注 0013 数据通道
            if packet.get("channel") == "0013":
                eeg_values = decode_athena_eeg(packet["data"])
                if eeg_values:
                    # 此时打印的就是真实的脑电电压值（微伏）
                    print(f"🧠 EEG Samples: {eeg_values[:4]}...") 
    except WebSocketDisconnect:
        print("🔴 断开连接")

if __name__ == "__main__":
    # 确保监听 0.0.0.0
    uvicorn.run(app, host="0.0.0.0", port=8001)