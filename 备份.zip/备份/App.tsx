import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Button, ScrollView, StyleSheet, Platform, PermissionsAndroid } from 'react-native';
import { BleManager, Device } from 'react-native-ble-plx';
import { Buffer } from 'buffer';

if (!global.Buffer) { global.Buffer = Buffer; }

// 将 BleManager 实例移到组件外部，实现单例模式
const bleManager = new BleManager();

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
// ⚠️ 请确保这是你电脑的 IP 地址
const WS_URL = 'ws://192.168.0.200:8001/ws/eeg';

const MUSE_SERVICE = '0000fe8d-0000-1000-8000-00805f9b34fb';
const MUSE_CONTROL = '273e0001-4c4d-454d-96be-f03bac821358';
// 使用更简洁的方式定义 Athena 数据通道
const ATHENA_CHANNELS = ['273e0013', '273e0014', '273e0015'].map(id => `${id}-4c4d-454d-96be-f03bac821358`);


export default function App() {
  const [status, setStatus] = useState('等待操作...');
  const [logs, setLogs] = useState<string[]>([]);
  const ws = useRef<WebSocket | null>(null);
  const isConnecting = useRef(false);

  const log = (msg: string) => {
    setLogs(prev => [msg, ...prev].slice(0, 15));
    setStatus(msg);
  };

  useEffect(() => {
    ws.current = new WebSocket(WS_URL);
    ws.current.onopen = () => log('🟢 成功连接 FastAPI 后端');
    ws.current.onerror = (e) => log(`🔴 后端连接失败`);

    return () => { 
      ws.current?.close(); 
    };
  }, []);

  // 简化并优化指令发送函数
  const sendCommand = async (device: Device, base64: string, name: string) => {
    return new Promise<void>(async (resolve) => {
      let resolved = false;
      let buffer = "";
      const sub = device.monitorCharacteristicForService(MUSE_SERVICE, MUSE_CONTROL, (err, char) => {
        if (err || resolved) return;
        if (char?.value) {
          const chunk = Buffer.from(char.value, 'base64').toString();
          buffer += chunk;
          if (buffer.includes('}') && buffer.includes('"rc":0')) {
            log(`✅ ${name} 成功`);
            resolved = true; 
            sub.remove(); 
            resolve();
          }
        }
      });
      
      await device.writeCharacteristicWithoutResponseForService(MUSE_SERVICE, MUSE_CONTROL, base64);
      
      setTimeout(() => { 
        if (!resolved) { 
          sub.remove(); 
          resolve(); 
        } 
      }, 2000);
    });
  };

  const startMuseProtocol = async (device: Device) => {
    try {
      log('🛡️ 启动 Athena 解锁序列...');
      
      // 1. 开启全局监听，同时监控主控制通道和所有Athena数据通道
      [MUSE_CONTROL, ...ATHENA_CHANNELS].forEach(uuid => {
        device.monitorCharacteristicForService(MUSE_SERVICE, uuid, (err, char) => {
          if (char?.value && ws.current?.readyState === 1) {
            // 提取通道ID并发送到后端
            const channel = uuid.substring(4,8);
            ws.current!.send(JSON.stringify({ channel, data: char.value }));
          }
        });
      });

      // 2. 执行握手序列
      await sendCommand(device, 'A3YxCg==', 'Version'); // v1
      await sendCommand(device, 'AmgK', 'Halt');        // h
      await sendCommand(device, 'BnAxMDM1Cg==', 'Preset p1035'); // p1035

      // 3. 核心：双发 dc001 激活推流
      log('🚀 激活推流 (dc001 x2)...');
      await device.writeCharacteristicWithoutResponseForService(MUSE_SERVICE, MUSE_CONTROL, 'BmRjMDAxCg==');
      await sleep(100);
      await device.writeCharacteristicWithoutResponseForService(MUSE_SERVICE, MUSE_CONTROL, 'A0wxCg=='); // L1
      await sleep(200);
      await device.writeCharacteristicWithoutResponseForService(MUSE_SERVICE, MUSE_CONTROL, 'BmRjMDAxCg==');
      
      log('🏁 协议序列完成，等待数据...');
    } catch (e: any) { 
      log(`❌ 协议异常: ${e.message}`); 
    }
  };

  const scanAndConnect = async () => {
    if (isConnecting.current) return;
    isConnecting.current = true;
    
    // 检查蓝牙状态
    const state = await bleManager.state();
    if (state !== 'PoweredOn') {
      log('蓝牙未开启，请先打开蓝牙');
      isConnecting.current = false;
      return;
    }
    
    log('正在请求蓝牙权限...');
    const hasPermission = await requestBluetoothPermission();
    if (!hasPermission) {
      isConnecting.current = false;
      return;
    }
    
    log('正在扫描 Muse...');
    bleManager.startDeviceScan(null, null, async (error, device) => {
      if (error) { 
        log(`扫描错误: ${error.message}`); 
        isConnecting.current = false; 
        return; 
      }
      
      if (device?.name?.includes('Muse')) {
        bleManager.stopDeviceScan();
        try {
          log('建立物理连接...');
          // 修复了原始代码中的bug：重复调用device.connect()
          const connectedDevice = await device.connect();
          await sleep(500);
          
          // 尝试扩容MTU以提高传输效率
          try {
            await connectedDevice.requestMTU(512);
            log('MTU 通道扩容至 512 字节完成');
          } catch (mtuErr) {
            log('MTU扩容被拒绝或不支持(可忽略)');
          }
          
          // 发现所有服务和特征值
          const readyDevice = await connectedDevice.discoverAllServicesAndCharacteristics();
          await sleep(500);
          log('✅ 服务发现完成');
          
          // 开始Muse协议通信
          startMuseProtocol(readyDevice);
        } catch (e: any) { 
          log(`连接失败: ${e.message}`); 
          isConnecting.current = false; 
        }
      }
    });
  };

  const requestBluetoothPermission = async () => {
    if (Platform.OS === 'android') {
      // Android 12 (S) 及以上版本需要特殊权限
      if (Platform.Version >= 31) {
        const granted = await PermissionsAndroid.requestMultiple([
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
        ]);

        const isScanGranted = granted['android.permission.BLUETOOTH_SCAN'] === PermissionsAndroid.RESULTS.GRANTED;
        const isConnectGranted = granted['android.permission.BLUETOOTH_CONNECT'] === PermissionsAndroid.RESULTS.GRANTED;

        if (isScanGranted && isConnectGranted) {
          log('✅ 蓝牙权限已获得 (Android 12+)');
          return true;
        } else {
          log('❌ 蓝牙权限被拒绝');
          return false;
        }
      } else {
        // Android 12 以下版本
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
        );

        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          log('✅ 位置权限已获得 (Android <12)');
          return true;
        } else {
          log('❌ 位置权限被拒绝');
          return false;
        }
      }
    } else {
      // iOS 权限请求
      const granted = await bleManager.requestDevicePermissions();
      if (granted) {
        log('✅ 蓝牙权限已获得 (iOS)');
        return true;
      } else {
        log('❌ 蓝牙权限被拒绝 (iOS)');
        return false;
      }
    }
  };


  return (
    <View style={styles.container}>
      <Text style={styles.title}>超级个体 BCI 中枢</Text>
      <View style={styles.statusBox}>
        <Text style={styles.statusText}>{status}</Text>
      </View>
      <Button title="开始连接" onPress={scanAndConnect} />
      <ScrollView style={styles.logBox}>
        {logs.map((l, i) => <Text key={i} style={styles.logText}>{l}</Text>)}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 30, backgroundColor: '#f5f5f5' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20 },
  statusBox: { padding: 15, backgroundColor: '#fff', borderRadius: 8, marginBottom: 10 },
  statusText: { fontSize: 16 },
  logBox: { flex: 1, backgroundColor: '#000', padding: 10, borderRadius: 8 },
  logText: { color: '#0f0', fontSize: 11, marginBottom: 2 }
});